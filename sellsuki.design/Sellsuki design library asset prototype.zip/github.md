repo: BearyCenter/sellsuki.design
branch: main

## Last sync
date: 2026-08-19T07:29:07Z
deploy: https://vercel.com/sellsuki1/sellsuki-design

### Updated in this project
- sellsuki.design.dc.html — หน้า library asset 10 หน้า, header รวมเมนู dropdown, home layout ใหม่
- index.html — redirect จาก root ไปหน้าหลัก (Vercel static)
- assets/ — brand mark SVG จาก DS 2.0

## Screen map
| screen | built from |
|---|---|
| ทุกหน้า (Overview, Set up, Tokens, Brand, Assets, Skills, Design system, Component library, Storybook, Design check) | sellsuki.design.dc.html |
| runtime | support.js |

## Sync history
- 2026-08-19 — push ครั้งแรกจาก BearyCenter/sellsuki.design (ก่อนหน้านี้ระบุ repo Watcharapong-cmd/sellsuki.design)
